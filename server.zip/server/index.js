import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { db } from './lib/db.js';
import { GameManager } from './lib/gameManager.js';
import { PushService } from './lib/pushService.js';
import { authMiddleware } from './lib/auth.js';
import { authRoutes } from './routes/auth.js';
import { tokenRoutes } from './routes/token.js';
import { taskRoutes } from './routes/task.js';
import { statusRoutes } from './routes/status.js';
import { settingsRoutes } from './routes/settings.js';
import { scheduledTaskRoutes } from './routes/scheduledTasks.js';

const PORT = process.env.PORT || 3001;

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

const httpServer = createServer(app);

const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
const pushService = new PushService(wss);
const gameManager = new GameManager(db, pushService);

app.use('/api/auth', authRoutes(db));
app.use('/api/token', authMiddleware, tokenRoutes(db, gameManager));
app.use('/api/task', authMiddleware, taskRoutes(gameManager));
app.use('/api/status', authMiddleware, statusRoutes(gameManager));
app.use('/api/settings', authMiddleware, settingsRoutes(db));
app.use('/api/scheduled-tasks', authMiddleware, scheduledTaskRoutes(db, gameManager));

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', uptime: process.uptime(), ready: gameManager.ready });
});

async function start() {
  await gameManager.init();
  httpServer.listen(PORT, () => {
    console.log(`[server] running on http://localhost:${PORT}`);
  });
}

start().catch((err) => {
  console.error('[server] 启动失败:', err);
  process.exit(1);
});
