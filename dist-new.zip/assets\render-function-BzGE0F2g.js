import{q as e}from"./index-DutlSoQv.js";var n=e({name:"RenderFunction",props:{renderFunc:{type:Function,required:!0}},render(){return this.renderFunc(this.$attrs)}});export{n as R};
